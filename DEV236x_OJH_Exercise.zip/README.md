Project to try code and excercises from the DEV236 Introduction to Python course
